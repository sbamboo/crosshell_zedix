# crosshell_zedix
Crosshell written in python (Codename: Zedix)

This project is in early development so packages are still included in this repostitory instead of being downloaded from official sources so please refer to the official sites for any files/packages/assets sourced from other places.


Currently applying licenses: License.txt, DevVersion_License.txt