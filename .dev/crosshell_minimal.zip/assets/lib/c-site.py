# C-Side "Crosshell-Scripting (simle) IDE"
# Made by: Simon Kalmi Claesson
#

# Main parser function
def cside_parser(content=str(),isfile=False,container=False): # Is file is false if content is string and true if content is filepath, container is true if file should be made to pyfile then run.
    pass

# Main class to be imported in cside files.
class cside_class():
    pass