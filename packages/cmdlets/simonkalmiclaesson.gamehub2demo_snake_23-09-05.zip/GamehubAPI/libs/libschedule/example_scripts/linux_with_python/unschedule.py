import os

os.system('python3 /home/$USER/libschedule/cliWrapper.py --unschedule -task_name "test"')