With the current stage of the API, please run the api with the "Python3" command

Also some libraries has some dependencies

libRSA:       cryptography,  "pip install cryptography"
libCrypto:    aes,           "pip install pyaes"
libpantryapi: requests,      "pip install requests"
