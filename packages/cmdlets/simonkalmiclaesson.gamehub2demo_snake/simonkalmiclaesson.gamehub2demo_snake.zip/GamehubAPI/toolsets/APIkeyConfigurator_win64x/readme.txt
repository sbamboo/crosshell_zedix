Run the .cmd file to handle pyEnviromentSetup

please also have the cryptography library installed:

<pypath>\python.exe -m pip install cryptography