import os

os.system('python3 /home/$USER/libschedule/cliWrapper.py --schedule -task_name "test" -interval_str "1_minutes" -script_path "/home/$USER/libschedule/example_scripts/test.py" -python_path "/usr/bin/python3"')