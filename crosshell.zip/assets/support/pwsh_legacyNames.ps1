# Legacy names
$script:basedir = $csbasedir